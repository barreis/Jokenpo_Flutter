# jokenpo flutter

## Aplicativo desenvolvido em Flutter

- Projeto: um jogo desenvolvida em Dart / Flutter para o curso de desenvolvimento de aplicativos.

